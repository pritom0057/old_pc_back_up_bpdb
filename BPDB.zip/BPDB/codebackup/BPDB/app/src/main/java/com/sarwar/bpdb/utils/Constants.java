package com.sarwar.bpdb.utils;

/**
 * Created by root on 6/24/18.
 */

public class Constants {

    public static String BASE_URL_PRE = "http://180.211.137.26:8091";
    public static String BASE_URL = "http://180.211.137.22:8992";
}
